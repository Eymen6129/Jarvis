import express from "express";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 3000);
const root = path.dirname(fileURLToPath(import.meta.url));

app.disable("x-powered-by");
app.use(express.json({ limit: "64kb" }));
app.use(express.static(path.join(root, "public"), {
  setHeaders(res, filePath) {
    if (filePath.endsWith("service-worker.js")) res.setHeader("Cache-Control", "no-cache");
  }
}));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENROUTER_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    const apiKey = process.env.OPENROUTER_API_KEY;
    if (!apiKey || apiKey === "PASTE_YOUR_NEW_KEY_HERE") {
      return res.status(503).json({ error: "API anahtarı ayarlanmamış. Proje klasöründeki .env dosyasını düzenle." });
    }
    if (!Array.isArray(req.body?.messages) || req.body.messages.length === 0) {
      return res.status(400).json({ error: "Mesaj bulunamadı." });
    }
    const messages = req.body.messages.slice(-16).map(item => ({
      role: item.role === "assistant" ? "assistant" : "user",
      content: String(item.content ?? "").slice(0, 5000)
    }));
    const upstream = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "HTTP-Referer": `http://localhost:${port}`,
        "X-Title": "J.A.R.V.I.S. Android"
      },
      body: JSON.stringify({
        model: process.env.OPENROUTER_MODEL || "openai/gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: "Sen J.A.R.V.I.S.'sin: Türkçe konuşan, sakin, zeki ve yardımcı bir kişisel yapay zekâ asistanısın. Kullanıcı başka bir dil istemedikçe daima doğal Türkçe cevap ver. Cevaplarını sesli okunmaya uygun, açık ve öz yaz. Gerçekleştirmediğin bir eylemi yaptığını iddia etme. Telefonu veya uygulamaları kontrol ettiğini iddia etme."
          },
          ...messages
        ],
        temperature: 0.65
      })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const message = data?.error?.message || `AI sağlayıcısı hata verdi (${upstream.status}).`;
      return res.status(upstream.status >= 500 ? 502 : upstream.status).json({ error: message });
    }
    const reply = data?.choices?.[0]?.message?.content;
    if (!reply) return res.status(502).json({ error: "Yapay zekâ boş cevap döndürdü." });
    res.json({ reply: String(reply) });
  } catch {
    res.status(502).json({ error: "Sunucu yapay zekâ servisine bağlanamadı. İnternet bağlantını kontrol et." });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`J.A.R.V.I.S. hazır: http://localhost:${port}`);
});
