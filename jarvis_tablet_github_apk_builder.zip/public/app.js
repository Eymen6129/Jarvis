const chat = document.getElementById("chat");
const form = document.getElementById("chatForm");
const promptInput = document.getElementById("prompt");
const sendBtn = document.getElementById("sendBtn");
const statusText = document.getElementById("statusText");
const connection = document.getElementById("connection");
const history = [];
const speakToggle = document.getElementById("speakToggle");
const micBtn = document.getElementById("micBtn");
let recognition = null;
let listening = false;
let selectedVoice = null;

function updateClock() {
  document.getElementById("clock").textContent = new Date().toLocaleTimeString("tr-TR", {hour:"2-digit", minute:"2-digit"});
}
updateClock(); setInterval(updateClock, 15000);

function addMessage(role, content, label) {
  const row = document.createElement("div");
  row.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "assistant" ? "J" : "S";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  const speaker = document.createElement("div");
  speaker.className = "speaker";
  speaker.textContent = label || (role === "assistant" ? "J.A.R.V.I.S. • YAPAY ZEKÂ" : "SEN • MESAJ");
  const body = document.createElement("div");
  body.textContent = content;
  bubble.append(speaker, body);
  row.append(avatar, bubble);
  chat.appendChild(row);
  chat.scrollTop = chat.scrollHeight;
  return row;
}

function loadVoices() {
  if (!("speechSynthesis" in window)) return;
  const voices = speechSynthesis.getVoices();
  selectedVoice = voices.find(v => v.lang?.toLowerCase() === "tr-tr")
    || voices.find(v => v.lang?.toLowerCase().startsWith("tr")) || null;
}
if ("speechSynthesis" in window) {
  loadVoices();
  speechSynthesis.onvoiceschanged = loadVoices;
}

function speak(text) {
  if (!speakToggle.checked || !("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "tr-TR";
  utterance.rate = 1;
  utterance.pitch = 1;
  if (selectedVoice) utterance.voice = selectedVoice;
  speechSynthesis.speak(utterance);
}
speakToggle.addEventListener("change", () => {
  if (!speakToggle.checked && "speechSynthesis" in window) speechSynthesis.cancel();
});

async function sendMessage(text) {
  const content = text.trim();
  if (!content || sendBtn.disabled) return;
  if (recognition && listening) { try { recognition.stop(); } catch {} }
  addMessage("user", content);
  history.push({role:"user", content});
  promptInput.value = "";
  sendBtn.disabled = true;
  sendBtn.innerHTML = "DÜŞÜNÜYOR <span>···</span>";
  statusText.textContent = "YANIT HAZIRLANIYOR";
  connection.textContent = "Yapay zekâ çalışıyor";
  const waiting = addMessage("assistant", "Bir saniye, düşünüyorum…", "J.A.R.V.I.S. • İŞLENİYOR");
  try {
    const response = await fetch("/api/chat", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({messages:history})
    });
    const data = await response.json();
    waiting.remove();
    if (!response.ok) throw new Error(data.error || "İstek başarısız oldu.");
    history.push({role:"assistant", content:data.reply});
    addMessage("assistant", data.reply);
    connection.textContent = "Bağlandı";
    speak(data.reply);
  } catch (err) {
    waiting.remove();
    addMessage("assistant", `Bu isteği tamamlayamadım. ${err.message}`, "J.A.R.V.I.S. • BAĞLANTI BİLGİSİ");
    connection.textContent = "Ayarları kontrol et";
  } finally {
    sendBtn.disabled = false;
    sendBtn.innerHTML = 'GÖNDER <span>➤</span>';
    statusText.textContent = "SİSTEM HAZIR";
    promptInput.focus();
  }
}
form.addEventListener("submit", e => { e.preventDefault(); sendMessage(promptInput.value); });
document.querySelectorAll(".suggestion").forEach(b => b.addEventListener("click", () => sendMessage(b.textContent)));
document.querySelectorAll(".tool").forEach(b => b.addEventListener("click", () => sendMessage(b.dataset.prompt)));
document.querySelectorAll(".nav[data-target]").forEach(b => b.addEventListener("click", () => {
  document.getElementById(b.dataset.target)?.scrollIntoView({behavior:"smooth"});
  document.querySelectorAll(".nav").forEach(n => n.classList.toggle("active", n === b));
  promptInput.focus();
}));
document.getElementById("voiceNav").addEventListener("click", () => micBtn.click());
document.getElementById("clearBtn").addEventListener("click", () => {
  history.length = 0;
  if ("speechSynthesis" in window) speechSynthesis.cancel();
  chat.replaceChildren();
  addMessage("assistant", "Sohbet temizlendi. Yeni bir konuşmaya hazırım.");
});

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.lang = "tr-TR";
  recognition.interimResults = true;
  recognition.continuous = false;
  let finalTranscript = "";
  recognition.onstart = () => {
    listening = true;
    finalTranscript = "";
    micBtn.classList.add("listening");
    document.getElementById("voiceState").textContent = "Seni dinliyorum";
    statusText.textContent = "MİKROFON AÇIK";
    promptInput.placeholder = "Dinliyorum... konuşabilirsin";
  };
  recognition.onresult = event => {
    let interim = "";
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const transcript = event.results[i][0].transcript;
      if (event.results[i].isFinal) finalTranscript += transcript;
      else interim += transcript;
    }
    promptInput.value = (finalTranscript + " " + interim).trim();
  };
  recognition.onerror = event => {
    if (event.error === "not-allowed" || event.error === "service-not-allowed") {
      addMessage("assistant", "Mikrofon izni verilmedi. Tarayıcı ayarlarından mikrofon iznini açıp tekrar dene.");
    } else if (event.error !== "no-speech" && event.error !== "aborted") {
      addMessage("assistant", "Ses tanıma çalışmadı. İnternet bağlantını ve tarayıcı desteğini kontrol et.");
    }
  };
  recognition.onend = () => {
    listening = false;
    micBtn.classList.remove("listening");
    document.getElementById("voiceState").textContent = "Beklemede";
    statusText.textContent = "SİSTEM HAZIR";
    promptInput.placeholder = "J.A.R.V.I.S.'e mesaj yaz...";
    const transcript = (finalTranscript || promptInput.value).trim();
    if (transcript) sendMessage(transcript);
  };
  micBtn.addEventListener("click", () => {
    if (listening) { recognition.stop(); return; }
    if ("speechSynthesis" in window) speechSynthesis.cancel();
    promptInput.value = "";
    try { recognition.start(); }
    catch { addMessage("assistant", "Mikrofon başlatılamadı. Birkaç saniye bekleyip tekrar dene."); }
  });
} else {
  document.getElementById("voiceState").textContent = "Desteklenmiyor";
  document.getElementById("voiceHint").textContent = "Ses tanıma bu tarayıcıda desteklenmiyor.";
  micBtn.addEventListener("click", () => addMessage("assistant", "Bu tarayıcı ses tanımayı desteklemiyor. Android'de Chrome ile dene veya mesajını yaz."));
}

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/service-worker.js").catch(() => {}));
}
fetch("/api/health").then(r => r.json()).then(data => {
  connection.textContent = data.configured ? "Hazır" : "API anahtarı eksik";
}).catch(() => { connection.textContent = "Sunucuya ulaşılamıyor"; });
