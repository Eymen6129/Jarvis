\
    import type { CapacitorConfig } from '@capacitor/cli';

    const config: CapacitorConfig = {
      appId: 'com.jarvis.personalai',
      appName: 'J.A.R.V.I.S.',
      webDir: 'public',
      server: {
        // Set GitHub Actions repository variable JARVIS_URL to the deployed HTTPS Render URL.
        url: process.env.JARVIS_URL || 'https://example.com',
        cleartext: false,
        androidScheme: 'https'
      }
    };

    export default config;
