# J.A.R.V.I.S. — Tablet-only cloud APK build

This repo template lets you deploy the Node.js + OpenRouter server and build a debug Android APK using GitHub Actions, without a PC.

## A. Create the GitHub repository from your tablet

1. Download this ZIP and extract it using your tablet's Files app. If ZIP extraction is difficult, use GitHub's website in Chrome with **Desktop site** enabled.
2. On github.com create a new repository named `jarvis-tablet`, set it to **Private**, and create it.
3. Upload the extracted project's files and folders to the repository root. Make sure `.github/workflows/build-apk.yml`, `server.js`, `package.json`, `capacitor.config.ts`, `render.yaml`, and `public/` are in the root/repo. Do not upload a `.env` file or API key.
   - GitHub's web uploader may not upload nested folders easily from Android. If so, use github.dev: open the repository, press `.` (period) or change `github.com` to `github.dev`, create/upload files and commit. Or use the GitHub mobile app for basic repository setup.
4. Commit files to the `main` branch.

## B. Deploy the secure API server (Render)

1. Open https://render.com in Chrome and sign in using GitHub.
2. Choose **New + → Blueprint** and select your `jarvis-tablet` repository. Render reads `render.yaml`.
3. When asked for `OPENROUTER_API_KEY`, enter a NEW OpenRouter key in Render's environment-variable form. Do not place it in source files, GitHub commits, or this APK. Rotate/revoke the key previously pasted in chat.
4. Create/deploy the service. Wait until it says Live. Copy the HTTPS service URL, e.g. `https://jarvis-ai-server.onrender.com` (use your actual URL).
5. Open the service URL in Chrome to check it responds with the app.

Free hosting can sleep when idle and may take a little while to wake up.

## C. Tell GitHub Actions the app URL

1. In your repository open **Settings → Secrets and variables → Actions → Variables**.
2. Click **New repository variable**.
3. Name: `JARVIS_URL`
4. Value: the exact HTTPS Render URL from step B, without a trailing slash, e.g. `https://jarvis-ai-server.onrender.com`.
5. Save the variable.

## D. Build APK in the cloud

1. Open repository → **Actions**.
2. Choose **Build J.A.R.V.I.S. Android APK** on the left.
3. Tap **Run workflow** → **Run workflow**. (A push to `main` also starts a build.)
4. Wait until the workflow finishes with a green check.
5. Open the successful workflow run, scroll to **Artifacts**, and download `jarvis-android-debug-apk`.
6. Extract that downloaded artifact ZIP on your tablet. It contains `app-debug.apk`.
7. Tap `app-debug.apk` to install. Android may ask you to allow installs from that browser/files app.

## E. Use the app

Open J.A.R.V.I.S., grant microphone permission if prompted, and enable speech output. Speech recognition requires browser/WebView support and typically a working network. The AI response requires internet access and the deployed server.

## Important limitations/security

- This is a **debug APK** for personal testing, not a Play Store release. A release build should be signed with a private signing key.
- The APK loads the hosted web app from `JARVIS_URL`; it needs internet access.
- Never place `OPENROUTER_API_KEY` in GitHub repository variables used by client builds, JavaScript, or the APK. Keep it only in Render's server environment.
- Rotate the API key that was pasted into chat.
- Before exposing the server widely, add rate limiting/authentication and configure usage limits in OpenRouter. This template is a starter and the endpoint does not yet require user authentication.
- If Actions fails, open the failed job and copy the last red error lines so they can be diagnosed.
